import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-registerbene',
  templateUrl: './registerbene.page.html',
  styleUrls: ['./registerbene.page.scss'],
})
export class RegisterbenePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
