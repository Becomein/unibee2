import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-accountpublicasso',
  templateUrl: './accountpublicasso.page.html',
  styleUrls: ['./accountpublicasso.page.scss'],
})
export class AccountpublicassoPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
